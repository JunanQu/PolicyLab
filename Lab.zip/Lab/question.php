<?php include('includes/init.php');

$current_page_id="index";

?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="stylesheet" type="text/css" href="style/style.css" media="all" />

  <!-- Adds the carousel to this file -->
  <title>Social Dynamic Lab-Policy Lab Pilot Testing</title>
  </head>


  <body onload="enableButton();">
   
   
    <!-- header -->
 	 <div class="header" id="myHeader">
  		<p2>Cornell University</p2>
  		<h2>Social Dynamic Lab</h2>
	</div>
   
   
    <div class="wrapper" id="question">
       
         <h1>
         Question Title 
         </h1>
         <p>
         Question text
         </p>
         <br>
         <br>

     <input type = "button"  class="button" id = "support" value = "Support" >
     <br>
     <input type = "button"  class="button" id = "Decline" value = "Decline" >




    </div>

  </body>
  </html>

</html>
