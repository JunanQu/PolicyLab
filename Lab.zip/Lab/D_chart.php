<?php 
create_image();

function create_image(){

$width = 101;
//change the height here
//1% = 3.2
$height = 150;

$image = imagecreate($width, $height);

$rand = imagecolorallocate($image, 74, 144, 226);

imagefill($image, 0, 0, $rand);
imagepng($image);
imagedestroy($image);

}?>