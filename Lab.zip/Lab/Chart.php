<?php include('includes/init.php')?>

<!DOCTYPE html>
<html>
<head>
<link href="style/style.css" rel="stylesheet" type="text/css"  />

  <title>Social Dynamic Lab-Policy Lab Pilot Testing</title>



</head>
<body>
 	 <div class="header" id="myHeader">
  		<p2>Cornell University</p2>
  		<h2>Social Dynamic Lab</h2>
	</div>
	
	    <div class="wrapper" id="question">
       
         <h1>
         Question Title 
         </h1>
         <p>
         Question text
         </p>
         <br>
         <br>
    
    
         <div class="bargraph" style= "width: 365px;">

    <ul class="bars">
        <li class="bar1 bluebar" style="height: 100px;">50</li>
        <li class="bar2 navybar" style="height: 170px;">90</li>

    </ul>
<ul class="label"><li style="color:#606060;">Democrat</li>
<li>Democrat</li> 
<li style="color:#606060;">republican</li>

<li>Republican</li>
<ul class="y-axis"><li>100</li><li>75</li><li>50</li><li>25</li><li>0</li></ul>
</div>





     <input type = "button"  class="button" id = "support" value = "Support" >
     <br>
     <input type = "button"  class="button" id = "Decline" value = "Decline" >




    </div>





</body>
</html>
